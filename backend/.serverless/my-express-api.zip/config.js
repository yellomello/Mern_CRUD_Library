export const PORT  = 5556;
export const DBURL = 'mongodb+srv://root:root@cluster0.kaw9x.mongodb.net/new_coll?retryWrites=true&w=majority&appName=Cluster0';